<?php

require('includes/header.php');
require('includes/navbar.php');
require('includes/main-hero.php');
require('includes/why-buy.php');
require('includes/cta.php');
require('includes/footer.php');