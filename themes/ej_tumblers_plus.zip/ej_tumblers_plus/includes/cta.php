<div style="background-color:#E948B6;">
    <div class="container thirsty-for-more">
        <h2>Thirsty For <br> More?</h2>
        <a href="/shop/"><button class="shop-all-products-button">
            Shop All Products
        </button></a>
        <div class="cta-email-list">
            <h6>Sign up for our email list and receive 15% off your first order!</h6>
            <form action="" class="cta-form">
                <input type="text" class="email-input" placeholder="email@example.com">
                <button class="subscribe-button">Subscribe</button>
            </form>
        </div>
    </div>
</div>