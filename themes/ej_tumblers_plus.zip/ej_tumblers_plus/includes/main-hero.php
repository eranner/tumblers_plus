<div style="background:#BC36C0;">
<div class="container category-chooser">
    <h2>Choose Your Category</h2>
    <h6>What's your style?</h6>
    <div id="carouselExample" class="carousel slide">
  <div class="carousel-inner">
    <?php echo load_category_cards();?>
    </div>
  </div>
  <button class="carousel-control-prev control-buttons" type="button" data-bs-target="#carouselExample" data-bs-slide="prev">
    <span class="carousel-control-prev-icon" aria-hidden="true"></span>
    <span class="visually-hidden">Previous</span>
  </button>
  <button class="carousel-control-next control-buttons" type="button" data-bs-target="#carouselExample" data-bs-slide="next">
    <span class="carousel-control-next-icon" aria-hidden="true"></span>
    <span class="visually-hidden">Next</span>
  </button>
</div>
<div class="shop-all-categories">
<a class="shop-all-categories" href="/shop/"><button>Shop All Categories</button></a>
</div>
</div>
</div>