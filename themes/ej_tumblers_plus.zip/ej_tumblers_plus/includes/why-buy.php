<div style="background: #F2E9F4;">
<div class="container why-buy-from-us">
    <h2>Why buy from us?</h2>
    <div class="reason-to-buy">
        <div >
            <img class="plus-sign" src="<?php echo get_theme_file_uri().'/photos/plus-sign.png';?>" alt="" class="img-fluid">
        </div>
        <div class="reason-text">Leak proof design keeps liquids in your tumbler - and off of your lap.</div>
    </div>

<div class="reason-to-buy">
        <div >
            <img class="plus-sign" src="<?php echo get_theme_file_uri().'/photos/plus-sign.png';?>" alt="" class="img-fluid">
        </div>
        <div class="reason-text">Keeps your hot beverages <span style="color:#F02764;">HOT</span> and your cold beverages <span style="color:#6773DF;">FREEZING!</span></div>
    </div>

<div class="reason-to-buy">
        <div >
            <img class="plus-sign" src="<?php echo get_theme_file_uri().'/photos/plus-sign.png';?>" alt="" class="img-fluid">
        </div>
        <div class="reason-text">High quality materials and custom design - much better than anything you’ll find on Etsy!</div>
    
</div>
</div>