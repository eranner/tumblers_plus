<?php

require('includes/header.php');
require('includes/navbar.php');
require('includes/cta.php');
require('includes/footer.php');